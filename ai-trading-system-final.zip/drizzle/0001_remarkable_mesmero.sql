CREATE TABLE `kse_index` (
	`id` int AUTO_INCREMENT NOT NULL,
	`indexValue` decimal(12,2) NOT NULL,
	`dayChange` decimal(8,2),
	`dayChangePercent` decimal(6,2),
	`volume` int,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `kse_index_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `performance_metrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`date` timestamp NOT NULL,
	`totalSignals` int DEFAULT 0,
	`successfulSignals` int DEFAULT 0,
	`failedSignals` int DEFAULT 0,
	`winRate` decimal(5,2),
	`totalProfit` decimal(12,2),
	`averageProfit` decimal(12,2),
	`maxProfit` decimal(12,2),
	`maxLoss` decimal(12,2),
	`profitFactor` decimal(8,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `performance_metrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `signal_performance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`signalId` int NOT NULL,
	`actualEntryPrice` decimal(12,2),
	`actualExitPrice` decimal(12,2),
	`actualProfit` decimal(12,2),
	`actualProfitPercent` decimal(6,2),
	`hitTargets` json,
	`hitStopLoss` boolean DEFAULT false,
	`accuracy` decimal(5,2),
	`executionTime` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `signal_performance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `signals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stockId` int NOT NULL,
	`signalType` enum('jackpot','scalping','upperLock') NOT NULL,
	`direction` enum('buy','sell') NOT NULL,
	`entryPrice` decimal(12,2) NOT NULL,
	`entryRange` json,
	`stopLoss` decimal(12,2) NOT NULL,
	`stopLossPercent` decimal(6,2),
	`takeProfits` json,
	`confidence` decimal(5,2),
	`status` enum('active','closed','cancelled') NOT NULL DEFAULT 'active',
	`reason` text,
	`aiAnalysis` text,
	`timeframe` enum('1m','5m','15m','1h','4h','1d') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`closedAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `signals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `smc_patterns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stockId` int NOT NULL,
	`patternType` enum('orderBlock','liquiditySweep','breakOfStructure','changeOfCharacter','fairValueGap') NOT NULL,
	`timeframe` enum('1m','5m','15m','1h','4h','1d') NOT NULL,
	`priceLevel` decimal(12,2) NOT NULL,
	`strength` enum('weak','moderate','strong') DEFAULT 'moderate',
	`description` text,
	`timestamp` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `smc_patterns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`symbol` varchar(20) NOT NULL,
	`name` varchar(255) NOT NULL,
	`sector` varchar(100),
	`currentPrice` decimal(12,2),
	`marketCap` decimal(18,2),
	`volume` int,
	`dayHigh` decimal(12,2),
	`dayLow` decimal(12,2),
	`yearHigh` decimal(12,2),
	`yearLow` decimal(12,2),
	`lastUpdated` timestamp DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stocks_id` PRIMARY KEY(`id`),
	CONSTRAINT `stocks_symbol_unique` UNIQUE(`symbol`)
);
--> statement-breakpoint
CREATE TABLE `strategies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`createdBy` int NOT NULL,
	`strategyType` enum('smcBased','aiDriven','hybrid') NOT NULL,
	`parameters` json,
	`isActive` boolean DEFAULT true,
	`version` int DEFAULT 1,
	`documentation` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `strategies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `strategy_documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`strategyId` int NOT NULL,
	`documentType` enum('word','pdf') NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileSize` int,
	`generatedBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `strategy_documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `technical_data` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stockId` int NOT NULL,
	`timeframe` enum('1m','5m','15m','1h','4h','1d') NOT NULL,
	`open` decimal(12,2) NOT NULL,
	`high` decimal(12,2) NOT NULL,
	`low` decimal(12,2) NOT NULL,
	`close` decimal(12,2) NOT NULL,
	`volume` int,
	`timestamp` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `technical_data_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`signalId` int NOT NULL,
	`stockId` int NOT NULL,
	`entryPrice` decimal(12,2) NOT NULL,
	`exitPrice` decimal(12,2),
	`quantity` int NOT NULL,
	`profit` decimal(12,2),
	`profitPercent` decimal(6,2),
	`status` enum('open','closed','cancelled') NOT NULL DEFAULT 'open',
	`entryTime` timestamp NOT NULL,
	`exitTime` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trades_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `whatsapp_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`signalId` int,
	`phoneNumber` varchar(20) NOT NULL,
	`messageType` enum('signal','alert','confirmation') NOT NULL,
	`messageContent` text NOT NULL,
	`status` enum('sent','failed','pending') NOT NULL DEFAULT 'pending',
	`externalId` varchar(100),
	`errorMessage` text,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `whatsapp_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','subscriber') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `whatsappNumber` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `isSubscribed` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `subscriptionTier` enum('free','basic','pro','premium') DEFAULT 'free';--> statement-breakpoint
ALTER TABLE `signal_performance` ADD CONSTRAINT `signal_performance_signalId_signals_id_fk` FOREIGN KEY (`signalId`) REFERENCES `signals`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `signals` ADD CONSTRAINT `signals_stockId_stocks_id_fk` FOREIGN KEY (`stockId`) REFERENCES `stocks`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `smc_patterns` ADD CONSTRAINT `smc_patterns_stockId_stocks_id_fk` FOREIGN KEY (`stockId`) REFERENCES `stocks`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `strategies` ADD CONSTRAINT `strategies_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `strategy_documents` ADD CONSTRAINT `strategy_documents_strategyId_strategies_id_fk` FOREIGN KEY (`strategyId`) REFERENCES `strategies`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `strategy_documents` ADD CONSTRAINT `strategy_documents_generatedBy_users_id_fk` FOREIGN KEY (`generatedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `technical_data` ADD CONSTRAINT `technical_data_stockId_stocks_id_fk` FOREIGN KEY (`stockId`) REFERENCES `stocks`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `trades` ADD CONSTRAINT `trades_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `trades` ADD CONSTRAINT `trades_signalId_signals_id_fk` FOREIGN KEY (`signalId`) REFERENCES `signals`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `trades` ADD CONSTRAINT `trades_stockId_stocks_id_fk` FOREIGN KEY (`stockId`) REFERENCES `stocks`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `whatsapp_logs` ADD CONSTRAINT `whatsapp_logs_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `whatsapp_logs` ADD CONSTRAINT `whatsapp_logs_signalId_signals_id_fk` FOREIGN KEY (`signalId`) REFERENCES `signals`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `timestamp_idx` ON `kse_index` (`timestamp`);--> statement-breakpoint
CREATE INDEX `date_idx` ON `performance_metrics` (`date`);--> statement-breakpoint
CREATE INDEX `signal_id_idx` ON `signal_performance` (`signalId`);--> statement-breakpoint
CREATE INDEX `stock_id_idx` ON `signals` (`stockId`);--> statement-breakpoint
CREATE INDEX `status_idx` ON `signals` (`status`);--> statement-breakpoint
CREATE INDEX `created_at_idx` ON `signals` (`createdAt`);--> statement-breakpoint
CREATE INDEX `stock_id_idx` ON `smc_patterns` (`stockId`);--> statement-breakpoint
CREATE INDEX `pattern_type_idx` ON `smc_patterns` (`patternType`);--> statement-breakpoint
CREATE INDEX `symbol_idx` ON `stocks` (`symbol`);--> statement-breakpoint
CREATE INDEX `created_by_idx` ON `strategies` (`createdBy`);--> statement-breakpoint
CREATE INDEX `strategy_id_idx` ON `strategy_documents` (`strategyId`);--> statement-breakpoint
CREATE INDEX `stock_id_idx` ON `technical_data` (`stockId`);--> statement-breakpoint
CREATE INDEX `timeframe_idx` ON `technical_data` (`timeframe`);--> statement-breakpoint
CREATE INDEX `timestamp_idx` ON `technical_data` (`timestamp`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `trades` (`userId`);--> statement-breakpoint
CREATE INDEX `signal_id_idx` ON `trades` (`signalId`);--> statement-breakpoint
CREATE INDEX `status_idx` ON `trades` (`status`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `whatsapp_logs` (`userId`);--> statement-breakpoint
CREATE INDEX `status_idx` ON `whatsapp_logs` (`status`);