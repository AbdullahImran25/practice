import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  json,
  index,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with trading-specific fields.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "subscriber"]).default("user").notNull(),
  whatsappNumber: varchar("whatsappNumber", { length: 20 }),
  isSubscribed: boolean("isSubscribed").default(false).notNull(),
  subscriptionTier: mysqlEnum("subscriptionTier", ["free", "basic", "pro", "premium"]).default("free"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * PSX Stock master data
 */
export const stocks = mysqlTable(
  "stocks",
  {
    id: int("id").autoincrement().primaryKey(),
    symbol: varchar("symbol", { length: 20 }).notNull().unique(),
    name: varchar("name", { length: 255 }).notNull(),
    sector: varchar("sector", { length: 100 }),
    currentPrice: decimal("currentPrice", { precision: 12, scale: 2 }),
    marketCap: decimal("marketCap", { precision: 18, scale: 2 }),
    volume: int("volume"),
    dayHigh: decimal("dayHigh", { precision: 12, scale: 2 }),
    dayLow: decimal("dayLow", { precision: 12, scale: 2 }),
    yearHigh: decimal("yearHigh", { precision: 12, scale: 2 }),
    yearLow: decimal("yearLow", { precision: 12, scale: 2 }),
    lastUpdated: timestamp("lastUpdated").defaultNow(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    symbolIdx: index("symbol_idx").on(table.symbol),
  })
);

export type Stock = typeof stocks.$inferSelect;
export type InsertStock = typeof stocks.$inferInsert;

/**
 * KSE-100 Index data for market sentiment
 */
export const kseIndex = mysqlTable(
  "kse_index",
  {
    id: int("id").autoincrement().primaryKey(),
    indexValue: decimal("indexValue", { precision: 12, scale: 2 }).notNull(),
    dayChange: decimal("dayChange", { precision: 8, scale: 2 }),
    dayChangePercent: decimal("dayChangePercent", { precision: 6, scale: 2 }),
    volume: int("volume"),
    timestamp: timestamp("timestamp").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    timestampIdx: index("timestamp_idx").on(table.timestamp),
  })
);

export type KseIndex = typeof kseIndex.$inferSelect;
export type InsertKseIndex = typeof kseIndex.$inferInsert;

/**
 * Technical analysis data (OHLCV candles)
 */
export const technicalData = mysqlTable(
  "technical_data",
  {
    id: int("id").autoincrement().primaryKey(),
    stockId: int("stockId").notNull().references(() => stocks.id),
    timeframe: mysqlEnum("timeframe", ["1m", "5m", "15m", "1h", "4h", "1d"]).notNull(),
    open: decimal("open", { precision: 12, scale: 2 }).notNull(),
    high: decimal("high", { precision: 12, scale: 2 }).notNull(),
    low: decimal("low", { precision: 12, scale: 2 }).notNull(),
    close: decimal("close", { precision: 12, scale: 2 }).notNull(),
    volume: int("volume"),
    timestamp: timestamp("timestamp").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    stockIdIdx: index("stock_id_idx").on(table.stockId),
    timeframeIdx: index("timeframe_idx").on(table.timeframe),
    timestampIdx: index("timestamp_idx").on(table.timestamp),
  })
);

export type TechnicalData = typeof technicalData.$inferSelect;
export type InsertTechnicalData = typeof technicalData.$inferInsert;

/**
 * Smart Money Concepts (SMC) patterns detected
 */
export const smcPatterns = mysqlTable(
  "smc_patterns",
  {
    id: int("id").autoincrement().primaryKey(),
    stockId: int("stockId").notNull().references(() => stocks.id),
    patternType: mysqlEnum("patternType", [
      "orderBlock",
      "liquiditySweep",
      "breakOfStructure",
      "changeOfCharacter",
      "fairValueGap",
    ]).notNull(),
    timeframe: mysqlEnum("timeframe", ["1m", "5m", "15m", "1h", "4h", "1d"]).notNull(),
    priceLevel: decimal("priceLevel", { precision: 12, scale: 2 }).notNull(),
    strength: mysqlEnum("strength", ["weak", "moderate", "strong"]).default("moderate"),
    description: text("description"),
    timestamp: timestamp("timestamp").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    stockIdIdx: index("stock_id_idx").on(table.stockId),
    patternTypeIdx: index("pattern_type_idx").on(table.patternType),
  })
);

export type SmcPattern = typeof smcPatterns.$inferSelect;
export type InsertSmcPattern = typeof smcPatterns.$inferInsert;

/**
 * AI-generated trading signals
 */
export const signals = mysqlTable(
  "signals",
  {
    id: int("id").autoincrement().primaryKey(),
    stockId: int("stockId").notNull().references(() => stocks.id),
    signalType: mysqlEnum("signalType", ["jackpot", "scalping", "upperLock"]).notNull(),
    direction: mysqlEnum("direction", ["buy", "sell"]).notNull(),
    entryPrice: decimal("entryPrice", { precision: 12, scale: 2 }).notNull(),
    entryRange: json("entryRange"), // {min, max}
    stopLoss: decimal("stopLoss", { precision: 12, scale: 2 }).notNull(),
    stopLossPercent: decimal("stopLossPercent", { precision: 6, scale: 2 }),
    takeProfits: json("takeProfits"), // Array of {level, price, percent}
    confidence: decimal("confidence", { precision: 5, scale: 2 }), // 0-100
    status: mysqlEnum("status", ["active", "closed", "cancelled"]).default("active").notNull(),
    reason: text("reason"), // Why the signal was generated
    aiAnalysis: text("aiAnalysis"), // LLM analysis
    timeframe: mysqlEnum("timeframe", ["1m", "5m", "15m", "1h", "4h", "1d"]).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    closedAt: timestamp("closedAt"),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    stockIdIdx: index("stock_id_idx").on(table.stockId),
    statusIdx: index("status_idx").on(table.status),
    createdAtIdx: index("created_at_idx").on(table.createdAt),
  })
);

export type Signal = typeof signals.$inferSelect;
export type InsertSignal = typeof signals.$inferInsert;

/**
 * Trade execution records
 */
export const trades = mysqlTable(
  "trades",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id),
    signalId: int("signalId").notNull().references(() => signals.id),
    stockId: int("stockId").notNull().references(() => stocks.id),
    entryPrice: decimal("entryPrice", { precision: 12, scale: 2 }).notNull(),
    exitPrice: decimal("exitPrice", { precision: 12, scale: 2 }),
    quantity: int("quantity").notNull(),
    profit: decimal("profit", { precision: 12, scale: 2 }),
    profitPercent: decimal("profitPercent", { precision: 6, scale: 2 }),
    status: mysqlEnum("status", ["open", "closed", "cancelled"]).default("open").notNull(),
    entryTime: timestamp("entryTime").notNull(),
    exitTime: timestamp("exitTime"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("user_id_idx").on(table.userId),
    signalIdIdx: index("signal_id_idx").on(table.signalId),
    statusIdx: index("status_idx").on(table.status),
  })
);

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = typeof trades.$inferInsert;

/**
 * Signal performance tracking
 */
export const signalPerformance = mysqlTable(
  "signal_performance",
  {
    id: int("id").autoincrement().primaryKey(),
    signalId: int("signalId").notNull().references(() => signals.id),
    actualEntryPrice: decimal("actualEntryPrice", { precision: 12, scale: 2 }),
    actualExitPrice: decimal("actualExitPrice", { precision: 12, scale: 2 }),
    actualProfit: decimal("actualProfit", { precision: 12, scale: 2 }),
    actualProfitPercent: decimal("actualProfitPercent", { precision: 6, scale: 2 }),
    hitTargets: json("hitTargets"), // Array of hit TP levels
    hitStopLoss: boolean("hitStopLoss").default(false),
    accuracy: decimal("accuracy", { precision: 5, scale: 2 }), // 0-100
    executionTime: int("executionTime"), // milliseconds
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    signalIdIdx: index("signal_id_idx").on(table.signalId),
  })
);

export type SignalPerformance = typeof signalPerformance.$inferSelect;
export type InsertSignalPerformance = typeof signalPerformance.$inferInsert;

/**
 * WhatsApp notification logs
 */
export const whatsappLogs = mysqlTable(
  "whatsapp_logs",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id),
    signalId: int("signalId").references(() => signals.id),
    phoneNumber: varchar("phoneNumber", { length: 20 }).notNull(),
    messageType: mysqlEnum("messageType", ["signal", "alert", "confirmation"]).notNull(),
    messageContent: text("messageContent").notNull(),
    status: mysqlEnum("status", ["sent", "failed", "pending"]).default("pending").notNull(),
    externalId: varchar("externalId", { length: 100 }), // Twilio/Meta message ID
    errorMessage: text("errorMessage"),
    sentAt: timestamp("sentAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("user_id_idx").on(table.userId),
    statusIdx: index("status_idx").on(table.status),
  })
);

export type WhatsappLog = typeof whatsappLogs.$inferSelect;
export type InsertWhatsappLog = typeof whatsappLogs.$inferInsert;

/**
 * Strategy documentation and configurations
 */
export const strategies = mysqlTable(
  "strategies",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    description: text("description"),
    createdBy: int("createdBy").notNull().references(() => users.id),
    strategyType: mysqlEnum("strategyType", ["smcBased", "aiDriven", "hybrid"]).notNull(),
    parameters: json("parameters"), // Configuration parameters
    isActive: boolean("isActive").default(true),
    version: int("version").default(1),
    documentation: text("documentation"), // HTML or markdown
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    createdByIdx: index("created_by_idx").on(table.createdBy),
  })
);

export type Strategy = typeof strategies.$inferSelect;
export type InsertStrategy = typeof strategies.$inferInsert;

/**
 * Strategy documentation exports (Word, PDF)
 */
export const strategyDocuments = mysqlTable(
  "strategy_documents",
  {
    id: int("id").autoincrement().primaryKey(),
    strategyId: int("strategyId").notNull().references(() => strategies.id),
    documentType: mysqlEnum("documentType", ["word", "pdf"]).notNull(),
    fileName: varchar("fileName", { length: 255 }).notNull(),
    fileUrl: text("fileUrl").notNull(),
    fileSize: int("fileSize"),
    generatedBy: int("generatedBy").notNull().references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    strategyIdIdx: index("strategy_id_idx").on(table.strategyId),
  })
);

export type StrategyDocument = typeof strategyDocuments.$inferSelect;
export type InsertStrategyDocument = typeof strategyDocuments.$inferInsert;

/**
 * Daily performance metrics and statistics
 */
export const performanceMetrics = mysqlTable(
  "performance_metrics",
  {
    id: int("id").autoincrement().primaryKey(),
    date: timestamp("date").notNull(),
    totalSignals: int("totalSignals").default(0),
    successfulSignals: int("successfulSignals").default(0),
    failedSignals: int("failedSignals").default(0),
    winRate: decimal("winRate", { precision: 5, scale: 2 }), // 0-100
    totalProfit: decimal("totalProfit", { precision: 12, scale: 2 }),
    averageProfit: decimal("averageProfit", { precision: 12, scale: 2 }),
    maxProfit: decimal("maxProfit", { precision: 12, scale: 2 }),
    maxLoss: decimal("maxLoss", { precision: 12, scale: 2 }),
    profitFactor: decimal("profitFactor", { precision: 8, scale: 2 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    dateIdx: index("date_idx").on(table.date),
  })
);

export type PerformanceMetrics = typeof performanceMetrics.$inferSelect;
export type InsertPerformanceMetrics = typeof performanceMetrics.$inferInsert;
