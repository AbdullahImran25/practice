import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, FileText, Download, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Strategies() {
  const strategies = [
    {
      id: 1,
      name: "SMC Pro Trader",
      type: "smcBased",
      description: "Advanced Smart Money Concepts focusing on institutional order blocks and liquidity sweeps.",
      winRate: "72%",
      active: true
    },
    {
      id: 2,
      name: "AI Scalper v2",
      type: "aiDriven",
      description: "High-frequency AI model trained on PSX historical data for quick scalp trades.",
      winRate: "68%",
      active: true
    }
  ];

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-8 p-4 md:p-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Trading Strategies</h1>
          <p className="text-muted-foreground mt-1">Explore and manage your active trading methodologies</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {strategies.map(strategy => (
            <Card key={strategy.id} className="overflow-hidden border-blue-100">
              <CardHeader className="bg-slate-50/50 border-b">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{strategy.name}</CardTitle>
                    <Badge className="mt-2 capitalize" variant="secondary">{strategy.type}</Badge>
                  </div>
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
              </CardHeader>
              <CardContent className="pt-6 space-y-4">
                <p className="text-sm text-slate-600 leading-relaxed">
                  {strategy.description}
                </p>
                
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <span className="text-xs font-bold text-blue-700">Estimated Win Rate</span>
                  <span className="text-lg font-bold text-blue-800">{strategy.winRate}</span>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <FileText className="w-4 h-4 mr-2" /> View Docs
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Download className="w-4 h-4 mr-2" /> Export PDF
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mb-4">
              <ExternalLink className="w-6 h-6 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium">Request Custom Strategy</h3>
            <p className="text-sm text-muted-foreground max-w-sm mt-1 mb-6">
              Have a specific trading methodology? Our AI can help you automate and optimize your custom strategies.
            </p>
            <Button variant="outline">Contact Support</Button>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
