import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { Smartphone, Bell, Shield, User } from "lucide-react";

export default function Profile() {
  const { user } = useAuth();
  const [whatsapp, setWhatsapp] = useState(user?.whatsappNumber || "");
  const [subscribed, setSubscribed] = useState(user?.isSubscribed || false);

  const updateMutation = trpc.auth.updateSubscription.useMutation({
    onSuccess: () => {
      toast.success("Settings updated successfully");
    },
    onError: (err) => {
      toast.error(`Update failed: ${err.message}`);
    }
  });

  const handleSave = () => {
    updateMutation.mutate({
      whatsappNumber: whatsapp,
      isSubscribed: subscribed
    });
  };

  if (!user) return <div className="flex items-center justify-center h-screen">Loading...</div>;

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-8 p-4 md:p-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">User Settings</h1>
          <p className="text-muted-foreground mt-1">Manage your profile and notification preferences</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1 space-y-4">
            <Card className="overflow-hidden">
              <div className="h-24 bg-gradient-to-r from-blue-600 to-blue-400" />
              <CardContent className="pt-0 flex flex-col items-center -mt-12">
                <div className="w-24 h-24 rounded-full border-4 border-white bg-slate-100 flex items-center justify-center text-slate-400 mb-4 shadow-sm">
                  <User className="w-12 h-12" />
                </div>
                <h2 className="font-bold text-lg">{user.name || "User Name"}</h2>
                <p className="text-sm text-muted-foreground">{user.email}</p>
                <Badge variant="outline" className="mt-2 capitalize">{user.role}</Badge>
              </CardContent>
            </Card>

            <div className="space-y-2">
              <Button variant="ghost" className="w-full justify-start text-blue-600 bg-blue-50">
                <User className="w-4 h-4 mr-2" /> Profile
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Bell className="w-4 h-4 mr-2" /> Notifications
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Shield className="w-4 h-4 mr-2" /> Security
              </Button>
            </div>
          </div>

          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-blue-600" /> WhatsApp Integration
                </CardTitle>
                <CardDescription>
                  Configure where you want to receive real-time trading signals.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="whatsapp">WhatsApp Number</Label>
                  <Input 
                    id="whatsapp" 
                    placeholder="+923001234567" 
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                  />
                  <p className="text-[10px] text-muted-foreground">Include country code (e.g., +92 for Pakistan)</p>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border">
                  <div className="space-y-0.5">
                    <Label className="text-base">Enable Signal Notifications</Label>
                    <p className="text-xs text-muted-foreground">Receive instant alerts for new trading opportunities.</p>
                  </div>
                  <Switch 
                    checked={subscribed}
                    onCheckedChange={setSubscribed}
                  />
                </div>

                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={handleSave}
                  disabled={updateMutation.isLoading}
                >
                  {updateMutation.isLoading ? "Saving..." : "Save Preferences"}
                </Button>
              </CardContent>
            </Card>

            <Card className="border-blue-100 bg-blue-50/30">
              <CardHeader>
                <CardTitle className="text-sm">Subscription Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-lg font-bold text-blue-800 capitalize">{user.subscriptionTier || "Free"} Plan</p>
                    <p className="text-xs text-blue-600">Your account is active and in good standing.</p>
                  </div>
                  <Button variant="outline" size="sm" className="border-blue-200 text-blue-600">Upgrade</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
