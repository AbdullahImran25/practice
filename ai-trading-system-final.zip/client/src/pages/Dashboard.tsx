import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, AlertCircle, CheckCircle, Plus, Send, Settings } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function Dashboard() {
  const { user } = useAuth();
  const [selectedSignal, setSelectedSignal] = useState<number | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const utils = trpc.useUtils();

  // Fetch active signals
  const { data: signals, isLoading: signalsLoading } = trpc.signals.getActive.useQuery();

  // Fetch analytics summary
  const { data: analytics } = trpc.analytics.getSummary.useQuery();

  // Mutations
  const generateMutation = trpc.signals.generate.useMutation({
    onSuccess: () => {
      toast.success("New signal generated successfully!");
      utils.signals.getActive.invalidate();
      utils.analytics.getSummary.invalidate();
      setIsGenerating(false);
    },
    onError: (err) => {
      toast.error(`Generation failed: ${err.message}`);
      setIsGenerating(false);
    }
  });

  const closeMutation = trpc.signals.close.useMutation({
    onSuccess: () => {
      toast.success("Signal closed successfully");
      utils.signals.getActive.invalidate();
      utils.analytics.getSummary.invalidate();
      setSelectedSignal(null);
    }
  });

  if (!user) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  const isAdmin = user.role === "admin";

  const handleGenerateSignal = () => {
    // For simplicity in this demo, we'll use some default values
    // In a real app, this would open a form
    const symbol = prompt("Enter Stock Symbol (e.g. ENGRO, LUCK):", "ENGRO");
    if (!symbol) return;

    setIsGenerating(true);
    generateMutation.mutate({
      symbol: symbol.toUpperCase(),
      timeframe: "1h",
      currentPrice: 300, // This would ideally be fetched real-time
      marketSentiment: "bullish",
      broadcast: true
    });
  };

  return (
    <DashboardLayout>
      <div className="space-y-8 p-4 md:p-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Trading Dashboard</h1>
            <p className="text-muted-foreground mt-1">Real-time AI-powered trading signals for PSX</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="icon">
              <Settings className="w-4 h-4" />
            </Button>
            {isAdmin && (
              <Button 
                onClick={handleGenerateSignal} 
                disabled={isGenerating}
                className="bg-blue-600 hover:bg-blue-700 shadow-md"
              >
                {isGenerating ? (
                  "Analyzing..."
                ) : (
                  <>
                    <Plus className="w-4 h-4 mr-2" /> Generate Signal
                  </>
                )}
              </Button>
            )}
          </div>
        </div>

        {/* Analytics Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-l-4 border-l-slate-400">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium uppercase text-muted-foreground">Total Signals</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics?.totalSignals || 0}</div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium uppercase text-muted-foreground">Active Signals</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{analytics?.activeSignals || 0}</div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium uppercase text-muted-foreground">Successful</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{analytics?.successfulSignals || 0}</div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium uppercase text-muted-foreground">Win Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {analytics?.winRate ? analytics.winRate.toFixed(1) : 0}%
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active Signals Table */}
        <Card className="shadow-sm">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Active Trading Signals</CardTitle>
                <CardDescription>Real-time signals generated by AI analysis</CardDescription>
              </div>
              <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
                {signals?.length || 0} Active
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {signalsLoading ? (
              <div className="flex flex-col items-center justify-center py-12 space-y-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <p className="text-muted-foreground">Loading signals...</p>
              </div>
            ) : signals && signals.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b text-muted-foreground text-xs uppercase">
                      <th className="text-left py-4 px-4 font-semibold">Stock</th>
                      <th className="text-left py-4 px-4 font-semibold">Type</th>
                      <th className="text-left py-4 px-4 font-semibold">Direction</th>
                      <th className="text-left py-4 px-4 font-semibold">Entry Price</th>
                      <th className="text-left py-4 px-4 font-semibold">Stop Loss</th>
                      <th className="text-left py-4 px-4 font-semibold">Confidence</th>
                      <th className="text-right py-4 px-4 font-semibold">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {signals.map((signal) => (
                      <tr key={signal.id} className="border-b hover:bg-slate-50 transition-colors">
                        <td className="py-4 px-4 font-bold text-slate-900">
                          {/* We'd ideally have the symbol here, but using stockId as placeholder for now */}
                          STOCK #{signal.stockId}
                        </td>
                        <td className="py-4 px-4">
                          <Badge variant="secondary" className="capitalize text-[10px]">
                            {signal.signalType}
                          </Badge>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-2">
                            {signal.direction === "buy" ? (
                              <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-none capitalize">
                                <TrendingUp className="w-3 h-3 mr-1" /> {signal.direction}
                              </Badge>
                            ) : (
                              <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-none capitalize">
                                <TrendingDown className="w-3 h-3 mr-1" /> {signal.direction}
                              </Badge>
                            )}
                          </div>
                        </td>
                        <td className="py-4 px-4 font-mono">{signal.entryPrice}</td>
                        <td className="py-4 px-4 font-mono text-red-600">{signal.stopLoss}</td>
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-2">
                            <div className="w-16 bg-slate-100 rounded-full h-1.5">
                              <div
                                className="bg-blue-600 h-1.5 rounded-full"
                                style={{ width: `${Math.min(100, Number(signal.confidence) || 0)}%` }}
                              />
                            </div>
                            <span className="text-xs font-medium">{signal.confidence}%</span>
                          </div>
                        </td>
                        <td className="py-4 px-4 text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                            onClick={() => setSelectedSignal(signal.id)}
                          >
                            View
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-12 border-2 border-dashed rounded-xl">
                <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-900">No active signals</h3>
                <p className="text-muted-foreground max-w-xs mx-auto mt-1">
                  New trading opportunities will appear here once generated by the AI engine.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Signal Details Panel */}
        {selectedSignal && signals && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <Card className="lg:col-span-2 shadow-md border-blue-100">
              <CardHeader className="border-b bg-slate-50/50">
                <div className="flex justify-between items-center">
                  <CardTitle>Signal Analysis</CardTitle>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedSignal(null)}>✕</Button>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                {signals.filter(s => s.id === selectedSignal).map(signal => (
                  <div key={signal.id} className="space-y-6">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-[10px] uppercase text-muted-foreground font-bold">Entry</p>
                        <p className="text-xl font-mono font-bold">{signal.entryPrice}</p>
                      </div>
                      <div className="p-3 bg-red-50 rounded-lg">
                        <p className="text-[10px] uppercase text-red-400 font-bold">Stop Loss</p>
                        <p className="text-xl font-mono font-bold text-red-600">{signal.stopLoss}</p>
                      </div>
                      <div className="p-3 bg-blue-50 rounded-lg col-span-2">
                        <p className="text-[10px] uppercase text-blue-400 font-bold">Timeframe</p>
                        <p className="text-xl font-bold text-blue-700">{signal.timeframe}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold mb-3 flex items-center">
                        <CheckCircle className="w-4 h-4 mr-2 text-green-500" /> Take Profit Targets
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        {Array.isArray(signal.takeProfits) && (signal.takeProfits as any[]).map((tp, idx) => (
                          <div key={idx} className="p-3 border rounded-lg bg-white flex justify-between items-center">
                            <span className="text-xs font-bold text-slate-500">TP{tp.level || idx+1}</span>
                            <span className="font-mono font-bold text-green-600">{tp.price || tp.percent + "%"}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold mb-2">Technical Rationale</h4>
                      <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-xl border">
                        {signal.reason || "Institutional accumulation detected at key demand zone. High probability setup based on SMC structure."}
                      </p>
                    </div>

                    {signal.aiAnalysis && (
                      <div>
                        <h4 className="text-sm font-bold mb-2">AI Deep Analysis</h4>
                        <div className="text-xs font-mono text-slate-500 bg-slate-900 p-4 rounded-xl text-white/90 overflow-x-auto">
                          {String(signal.aiAnalysis)}
                        </div>
                      </div>
                    )}

                    {isAdmin && (
                      <div className="pt-4 flex gap-3">
                        <Button 
                          className="flex-1 bg-red-600 hover:bg-red-700"
                          onClick={() => {
                            if(confirm("Are you sure you want to close this signal?")) {
                              closeMutation.mutate({ signalId: signal.id });
                            }
                          }}
                        >
                          Close Signal
                        </Button>
                        <Button variant="outline" className="flex-1">
                          <Send className="w-4 h-4 mr-2" /> Resend Alert
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardHeader className="border-b bg-slate-50/50">
                <CardTitle className="text-base">Market Sentiment</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="inline-flex items-center justify-center w-24 h-24 rounded-full border-8 border-green-100 bg-green-50 text-green-600 mb-2">
                      <TrendingUp className="w-10 h-10" />
                    </div>
                    <h4 className="font-bold text-lg">Bullish</h4>
                    <p className="text-xs text-muted-foreground">KSE-100 Index Trend</p>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Volume</span>
                      <span className="font-bold text-green-600">High</span>
                    </div>
                    <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full w-[80%]" />
                    </div>
                    
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Volatility</span>
                      <span className="font-bold text-blue-600">Moderate</span>
                    </div>
                    <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
                      <div className="bg-blue-500 h-full w-[45%]" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
