/**
 * Trading Engine: Core logic for SMC analysis, pattern detection, and signal generation
 */

import { invokeLLM } from "./_core/llm";
import {
  createSignal,
  createSmcPattern,
  getRecentTechnicalData,
  getStockBySymbol,
  upsertSignalPerformance,
} from "./db";
import type { TechnicalData } from "../drizzle/schema";

export interface PriceLevel {
  price: number;
  strength: "weak" | "moderate" | "strong";
  type: "support" | "resistance";
}

export interface OrderBlock {
  high: number;
  low: number;
  timeframe: string;
  strength: "weak" | "moderate" | "strong";
  description: string;
}

export interface SignalGenerationInput {
  symbol: string;
  timeframe: "1m" | "5m" | "15m" | "1h" | "4h" | "1d";
  currentPrice: number;
  marketSentiment: "bullish" | "bearish" | "neutral";
}

export interface GeneratedSignal {
  type: "jackpot" | "scalping" | "upperLock";
  direction: "buy" | "sell";
  entryPrice: number;
  entryRange: { min: number; max: number };
  stopLoss: number;
  stopLossPercent: number;
  takeProfits: Array<{ level: number; percent: number }>;
  confidence: number;
  reason: string;
  aiAnalysis: string;
}

/**
 * Detect Order Blocks (SMC concept)
 * Order blocks are areas where institutional orders are placed
 */
export function detectOrderBlocks(candles: TechnicalData[]): OrderBlock[] {
  if (candles.length < 5) return [];

  const blocks: OrderBlock[] = [];

  // Simple order block detection: identify areas where price reversed
  for (let i = 2; i < candles.length - 2; i++) {
    const prev = candles[i - 1];
    const current = candles[i];
    const next = candles[i + 1];

    // Detect bearish order block (high that wasn't broken)
    if (
      Number(prev.high) > Number(current.high) &&
      Number(current.high) > Number(next.high)
    ) {
      blocks.push({
        high: Number(current.high),
        low: Number(current.low),
        timeframe: current.timeframe,
        strength: "moderate",
        description: "Bearish Order Block - Previous high not broken",
      });
    }

    // Detect bullish order block (low that wasn't broken)
    if (Number(prev.low) < Number(current.low) && Number(current.low) < Number(next.low)) {
      blocks.push({
        high: Number(current.high),
        low: Number(current.low),
        timeframe: current.timeframe,
        strength: "moderate",
        description: "Bullish Order Block - Previous low not broken",
      });
    }
  }

  return blocks;
}

/**
 * Detect Liquidity Sweeps (SMC concept)
 * Areas where price briefly touches support/resistance before reversing
 */
export function detectLiquiditySweeps(
  candles: TechnicalData[],
  supportResistance: PriceLevel[]
): PriceLevel[] {
  if (candles.length < 3) return [];

  const sweeps: PriceLevel[] = [];

  for (const level of supportResistance) {
    for (let i = 1; i < candles.length; i++) {
      const prev = candles[i - 1];
      const current = candles[i];

      // Sweep above resistance
      if (
        Number(prev.high) < level.price &&
        Number(current.high) >= level.price &&
        Number(current.close) < level.price
      ) {
        sweeps.push({
          price: level.price,
          strength: "strong",
          type: "resistance",
        });
      }

      // Sweep below support
      if (
        Number(prev.low) > level.price &&
        Number(current.low) <= level.price &&
        Number(current.close) > level.price
      ) {
        sweeps.push({
          price: level.price,
          strength: "strong",
          type: "support",
        });
      }
    }
  }

  return sweeps;
}

/**
 * Detect Break of Structure (BoS) - SMC concept
 * When price breaks a previous high or low
 */
export function detectBreakOfStructure(candles: TechnicalData[]): PriceLevel[] {
  if (candles.length < 10) return [];

  const bosLevels: PriceLevel[] = [];

  // Find recent swing highs and lows
  for (let i = 5; i < candles.length - 2; i++) {
    let isSwingHigh = true;
    let isSwingLow = true;

    // Check if it's a swing high (higher highs on both sides)
    for (let j = i - 2; j <= i + 2; j++) {
      if (j !== i && Number(candles[j].high) >= Number(candles[i].high)) {
        isSwingHigh = false;
        break;
      }
    }

    // Check if it's a swing low (lower lows on both sides)
    for (let j = i - 2; j <= i + 2; j++) {
      if (j !== i && Number(candles[j].low) <= Number(candles[i].low)) {
        isSwingLow = false;
        break;
      }
    }

    if (isSwingHigh) {
      bosLevels.push({
        price: Number(candles[i].high),
        strength: "strong",
        type: "resistance",
      });
    }

    if (isSwingLow) {
      bosLevels.push({
        price: Number(candles[i].low),
        strength: "strong",
        type: "support",
      });
    }
  }

  return bosLevels;
}

/**
 * Calculate support and resistance levels
 */
export function calculateSupportResistance(candles: TechnicalData[]): PriceLevel[] {
  if (candles.length < 20) return [];

  const levels: PriceLevel[] = [];
  const highPrices = candles.map((c) => Number(c.high));
  const lowPrices = candles.map((c) => Number(c.low));

  // Find the highest and lowest prices
  const maxHigh = Math.max(...highPrices);
  const minLow = Math.min(...lowPrices);

  // Divide into zones and find resistance (peaks) and support (troughs)
  const zoneSize = (maxHigh - minLow) / 5;

  for (let zone = 0; zone < 5; zone++) {
    const zoneStart = minLow + zone * zoneSize;
    const zoneEnd = zoneStart + zoneSize;

    const highsInZone = highPrices.filter((h) => h >= zoneStart && h <= zoneEnd);
    const lowsInZone = lowPrices.filter((l) => l >= zoneStart && l <= zoneEnd);

    if (highsInZone.length > 2) {
      const avgHigh = highsInZone.reduce((a, b) => a + b) / highsInZone.length;
      levels.push({
        price: avgHigh,
        strength: highsInZone.length > 5 ? "strong" : "moderate",
        type: "resistance",
      });
    }

    if (lowsInZone.length > 2) {
      const avgLow = lowsInZone.reduce((a, b) => a + b) / lowsInZone.length;
      levels.push({
        price: avgLow,
        strength: lowsInZone.length > 5 ? "strong" : "moderate",
        type: "support",
      });
    }
  }

  return levels;
}

/**
 * Generate trading signals using AI analysis
 */
export async function generateTradingSignal(
  input: SignalGenerationInput,
  stockId: number
): Promise<GeneratedSignal | null> {
  try {
    // Get recent technical data
    const technicalCandles = await getRecentTechnicalData(stockId, input.timeframe, 100);

    if (technicalCandles.length < 20) {
      console.warn(`Insufficient technical data for ${input.symbol}`);
      return null;
    }

    // Perform SMC analysis
    const orderBlocks = detectOrderBlocks(technicalCandles);
    const supportResistance = calculateSupportResistance(technicalCandles);
    const bosLevels = detectBreakOfStructure(technicalCandles);
    const liquiditySweeps = detectLiquiditySweeps(technicalCandles, supportResistance);

    // Prepare analysis context for LLM
    const analysisContext = {
      symbol: input.symbol,
      currentPrice: input.currentPrice,
      timeframe: input.timeframe,
      marketSentiment: input.marketSentiment,
      orderBlocks: orderBlocks.slice(0, 3),
      supportResistance: supportResistance.slice(0, 5),
      bosLevels: bosLevels.slice(0, 3),
      liquiditySweeps: liquiditySweeps.slice(0, 3),
      recentCandles: technicalCandles.slice(0, 10).map((c) => ({
        timestamp: c.timestamp,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
        volume: c.volume,
      })),
    };

    // Use LLM to generate signal
    const llmPrompt = `
You are an expert technical analyst specializing in Smart Money Concepts (SMC) and AI-driven trading strategies for the Pakistan Stock Exchange (PSX).

Analyze the following technical data and SMC patterns for ${input.symbol}:

Current Price: ${input.currentPrice}
Timeframe: ${input.timeframe}
Market Sentiment: ${input.marketSentiment}

Order Blocks: ${JSON.stringify(orderBlocks.slice(0, 3))}
Support/Resistance Levels: ${JSON.stringify(supportResistance.slice(0, 5))}
Break of Structure Levels: ${JSON.stringify(bosLevels.slice(0, 3))}
Liquidity Sweeps: ${JSON.stringify(liquiditySweeps.slice(0, 3))}

Recent Price Action:
${technicalCandles
  .slice(0, 10)
  .map(
    (c) =>
      `O: ${c.open}, H: ${c.high}, L: ${c.low}, C: ${c.close}, V: ${c.volume}`
  )
  .join("\n")}

Based on this analysis, generate a trading signal with the following JSON format:
{
  "type": "jackpot|scalping|upperLock",
  "direction": "buy|sell",
  "entryPrice": number,
  "entryRange": {"min": number, "max": number},
  "stopLoss": number,
  "stopLossPercent": number,
  "takeProfits": [{"level": 1, "percent": 10}, {"level": 2, "percent": 20}],
  "confidence": 0-100,
  "reason": "Brief explanation of why this signal was generated",
  "analysis": "Detailed technical analysis explaining the signal"
}

Only respond with valid JSON, no additional text.
`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are an expert technical analyst. Respond only with valid JSON containing trading signals.",
        },
        {
          role: "user",
          content: llmPrompt,
        },
      ],
    });

    // Parse LLM response
    const responseText =
      typeof response.choices[0].message.content === "string"
        ? response.choices[0].message.content
        : "";

    // Extract JSON from response
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.warn("No valid JSON found in LLM response");
      return null;
    }

    const signal = JSON.parse(jsonMatch[0]) as GeneratedSignal;

    // Validate signal
    if (
      !signal.type ||
      !signal.direction ||
      !signal.entryPrice ||
      !signal.stopLoss ||
      !signal.takeProfits
    ) {
      console.warn("Invalid signal structure from LLM");
      return null;
    }

    return signal;
  } catch (error) {
    console.error("Error generating trading signal:", error);
    return null;
  }
}

/**
 * Calculate signal accuracy based on actual execution
 */
export async function calculateSignalAccuracy(
  signalId: number,
  actualEntryPrice: number,
  actualExitPrice: number,
  expectedStopLoss: number,
  expectedTargets: number[]
) {
  const profit = actualExitPrice - actualEntryPrice;
  const profitPercent = (profit / actualEntryPrice) * 100;

  // Check if targets were hit
  const hitTargets: number[] = [];
  for (const target of expectedTargets) {
    if (actualExitPrice >= target) {
      hitTargets.push(target);
    }
  }

  // Check if stop loss was hit
  const hitStopLoss = actualExitPrice <= expectedStopLoss;

  // Calculate accuracy (0-100)
  let accuracy = 0;
  if (hitStopLoss) {
    accuracy = 0; // Signal failed
  } else if (hitTargets.length > 0) {
    accuracy = Math.min(100, (hitTargets.length / expectedTargets.length) * 100);
  } else if (profit > 0) {
    accuracy = 50; // Partial success
  }

  await upsertSignalPerformance(signalId, {
    actualEntryPrice: actualEntryPrice.toString(),
    actualExitPrice: actualExitPrice.toString(),
    actualProfit: profit.toString(),
    actualProfitPercent: profitPercent.toString(),
    hitTargets: hitTargets,
    hitStopLoss,
    accuracy: accuracy.toString(),
  });

  return {
    accuracy: accuracy.toString(),
    profit: profit.toString(),
    profitPercent: profitPercent.toString(),
    hitTargets,
    hitStopLoss,
  };
}
