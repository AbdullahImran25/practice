import { drizzle } from "drizzle-orm/mysql2";
import { stocks, technicalData, kseIndex } from "../drizzle/schema";
import * as dotenv from "dotenv";
dotenv.config();

async function seed() {
  if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL not found");
    return;
  }

  const db = drizzle(process.env.DATABASE_URL);

  console.log("🌱 Seeding mock PSX data...");

  // 1. Seed Stocks
  const stockList = [
    { symbol: "ENGRO", name: "Engro Corporation Limited", sector: "Fertilizer" },
    { symbol: "LUCK", name: "Lucky Cement Limited", sector: "Cement" },
    { symbol: "HUBC", name: "Hub Power Company Limited", sector: "Power Generation" },
    { symbol: "MCB", name: "MCB Bank Limited", sector: "Commercial Banks" },
    { symbol: "SYS", name: "Systems Limited", sector: "Technology" },
  ];

  for (const s of stockList) {
    await db.insert(stocks).values({
      ...s,
      currentPrice: (Math.random() * 500 + 50).toString(),
    }).onDuplicateKeyUpdate({ set: { symbol: s.symbol } });
  }

  const allStocks = await db.select().from(stocks);
  
  // 2. Seed KSE Index
  await db.insert(kseIndex).values({
    indexValue: "65432.10",
    dayChange: "123.45",
    dayChangePercent: "0.19",
    volume: 500000000,
  });

  // 3. Seed Technical Data (Candles)
  for (const stock of allStocks) {
    console.log(`  Generating candles for ${stock.symbol}...`);
    const candles = [];
    let basePrice = Number(stock.currentPrice) || 100;
    
    for (let i = 0; i < 50; i++) {
      const open = basePrice + (Math.random() * 10 - 5);
      const close = open + (Math.random() * 10 - 5);
      const high = Math.max(open, close) + Math.random() * 5;
      const low = Math.min(open, close) - Math.random() * 5;
      
      candles.push({
        stockId: stock.id,
        timeframe: "1h" as any,
        open: open.toString(),
        high: high.toString(),
        low: low.toString(),
        close: close.toString(),
        volume: Math.floor(Math.random() * 1000000),
        timestamp: new Date(Date.now() - i * 3600000),
      });
      basePrice = close;
    }
    
    await db.insert(technicalData).values(candles);
  }

  console.log("✅ Mock data seeded successfully!");
  process.exit(0);
}

seed().catch(err => {
  console.error("Seed failed:", err);
  process.exit(1);
});
