import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getActiveSignals,
  getSignalsByStockId,
  getStockBySymbol,
  createSignal,
  updateSignalStatus,
  getPerformanceMetrics,
  getStrategyById,
  createStrategy,
  getStrategyDocuments,
  getAllSignals,
  getActiveSubscribers,
  updateUserSubscription,
} from "./db";
import { generateTradingSignal } from "./tradingEngine";
import { sendAlertViaWhatsapp, broadcastSignalToSubscribers, type WhatsappConfig } from "./whatsappService";
import { ENV } from "./_core/env";
import type { InsertSignal } from "../drizzle/schema";

const getWhatsappConfig = (): WhatsappConfig => ({
  provider: ENV.whatsappProvider,
  accountSid: ENV.twilioAccountSid,
  authToken: ENV.twilioAuthToken,
  phoneNumber: ENV.twilioPhoneNumber,
  accessToken: ENV.metaAccessToken,
  phoneNumberId: ENV.metaPhoneNumberId,
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    updateSubscription: protectedProcedure
      .input(z.object({
        whatsappNumber: z.string().optional(),
        isSubscribed: z.boolean().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        await updateUserSubscription(ctx.user.id, input);
        return { success: true };
      }),
  }),

  // ============ TRADING SIGNALS ============
  signals: router({
    getActive: publicProcedure.query(async () => {
      return await getActiveSignals();
    }),

    getByStock: publicProcedure
      .input(z.object({ symbol: z.string() }))
      .query(async ({ input }) => {
        const stock = await getStockBySymbol(input.symbol);
        if (!stock) return [];
        return await getSignalsByStockId(stock.id);
      }),

    generate: protectedProcedure
      .input(
        z.object({
          symbol: z.string(),
          timeframe: z.enum(["1m", "5m", "15m", "1h", "4h", "1d"]),
          currentPrice: z.number(),
          marketSentiment: z.enum(["bullish", "bearish", "neutral"]),
          broadcast: z.boolean().default(true),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Only admins can generate signals");
        }

        const stock = await getStockBySymbol(input.symbol);
        if (!stock) throw new Error(`Stock ${input.symbol} not found`);

        const signal = await generateTradingSignal(input, stock.id);
        if (!signal) throw new Error("Failed to generate signal");

        const signalData: InsertSignal = {
          stockId: stock.id,
          signalType: signal.type,
          direction: signal.direction,
          entryPrice: signal.entryPrice.toString(),
          entryRange: signal.entryRange,
          stopLoss: signal.stopLoss.toString(),
          stopLossPercent: signal.stopLossPercent.toString(),
          takeProfits: signal.takeProfits,
          confidence: signal.confidence.toString(),
          status: "active",
          reason: signal.reason,
          aiAnalysis: signal.aiAnalysis,
          timeframe: input.timeframe,
        };

        const result = await createSignal(signalData);
        const signalId = (result as any)[0].insertId;

        // Broadcast if requested
        if (input.broadcast) {
          const subscribers = await getActiveSubscribers();
          const subscribersWithNumbers = subscribers
            .filter(s => !!s.whatsappNumber)
            .map(s => ({ id: s.id, whatsappNumber: s.whatsappNumber! }));
          
          if (subscribersWithNumbers.length > 0) {
            // We use a detached promise or just wait for it
            broadcastSignalToSubscribers(
              getWhatsappConfig(),
              { ...signalData, id: signalId } as any,
              stock.symbol,
              subscribersWithNumbers
            ).catch(err => console.error("Broadcast failed:", err));
          }
        }

        return { success: true, signalId };
      }),

    close: protectedProcedure
      .input(z.object({ signalId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Only admins can close signals");
        }
        await updateSignalStatus(input.signalId, "closed");
        return { success: true };
      }),
  }),

  // ============ WHATSAPP ============
  whatsapp: router({
    test: protectedProcedure
      .input(z.object({ phoneNumber: z.string() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") throw new Error("Admin only");
        
        const result = await sendAlertViaWhatsapp(
          getWhatsappConfig(),
          ctx.user.id,
          input.phoneNumber,
          "WhatsApp Test",
          "This is a test message from your AI Trading System."
        );
        
        return result;
      }),
  }),

  // ============ PERFORMANCE & ANALYTICS ============
  analytics: router({
    getMetrics: publicProcedure
      .input(z.object({ startDate: z.date(), endDate: z.date() }))
      .query(async ({ input }) => {
        return await getPerformanceMetrics(input.startDate, input.endDate);
      }),

    getSummary: publicProcedure.query(async () => {
      const allSigs = await getAllSignals();
      const totalSignals = allSigs.length;
      const closedSignals = allSigs.filter(s => s.status === "closed");
      const activeSignals = allSigs.filter(s => s.status === "active");
      
      // For now, let's assume closed signals are successful for simplicity
      // In a real system, we'd check signalPerformance table
      const successfulSignals = closedSignals.length;
      const winRate = totalSignals > 0 ? ((successfulSignals / totalSignals) * 100).toFixed(2) : "0";

      return {
        totalSignals,
        successfulSignals,
        winRate: parseFloat(winRate),
        activeSignals: activeSignals.length,
      };
    }),
  }),

  // ============ STRATEGIES ============
  strategies: router({
    get: publicProcedure
      .input(z.object({ strategyId: z.number() }))
      .query(async ({ input }) => {
        return await getStrategyById(input.strategyId);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        strategyType: z.enum(["smcBased", "aiDriven", "hybrid"]),
        parameters: z.record(z.string(), z.any()).optional(),
        documentation: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") throw new Error("Admin only");
        await createStrategy({
          ...input,
          createdBy: ctx.user.id,
        });
        return { success: true };
      }),

    getDocuments: publicProcedure
      .input(z.object({ strategyId: z.number() }))
      .query(async ({ input }) => {
        return await getStrategyDocuments(input.strategyId);
      }),
  }),

  // ============ STOCKS ============
  stocks: router({
    get: publicProcedure
      .input(z.object({ symbol: z.string() }))
      .query(async ({ input }) => {
        return await getStockBySymbol(input.symbol);
      }),
  }),
});

export type AppRouter = typeof appRouter;
