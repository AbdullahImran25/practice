import { eq, desc, and, gte, lte, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  stocks,
  signals,
  trades,
  technicalData,
  smcPatterns,
  signalPerformance,
  whatsappLogs,
  strategies,
  strategyDocuments,
  performanceMetrics,
  kseIndex,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "whatsappNumber"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ TRADING QUERIES ============

/**
 * Get a stock by symbol
 */
export async function getStockBySymbol(symbol: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(stocks).where(eq(stocks.symbol, symbol)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get all active signals
 */
export async function getActiveSignals() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(signals)
    .where(eq(signals.status, "active"))
    .orderBy(desc(signals.createdAt));
}

/**
 * Get signals for a specific stock
 */
export async function getSignalsByStockId(stockId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(signals)
    .where(eq(signals.stockId, stockId))
    .orderBy(desc(signals.createdAt));
}

/**
 * Create a new trading signal
 */
export async function createSignal(signalData: typeof signals.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(signals).values(signalData);
  return result;
}

/**
 * Update signal status
 */
export async function updateSignalStatus(
  signalId: number,
  status: "active" | "closed" | "cancelled"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(signals)
    .set({ status, closedAt: new Date(), updatedAt: new Date() })
    .where(eq(signals.id, signalId));
}

/**
 * Get recent technical data for a stock
 */
export async function getRecentTechnicalData(
  stockId: number,
  timeframe: string,
  limit: number = 100
) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(technicalData)
    .where(and(eq(technicalData.stockId, stockId), eq(technicalData.timeframe, timeframe as any)))
    .orderBy(desc(technicalData.timestamp))
    .limit(limit);
}

/**
 * Get SMC patterns for a stock
 */
export async function getSmcPatterns(stockId: number, timeframe?: string) {
  const db = await getDb();
  if (!db) return [];

  const conditions: any[] = [eq(smcPatterns.stockId, stockId)];
  if (timeframe) {
    conditions.push(eq(smcPatterns.timeframe, timeframe as any));
  }

  return await db
    .select()
    .from(smcPatterns)
    .where(and(...conditions))
    .orderBy(desc(smcPatterns.timestamp));
}

/**
 * Create SMC pattern record
 */
export async function createSmcPattern(patternData: typeof smcPatterns.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(smcPatterns).values(patternData);
}

/**
 * Get signal performance
 */
export async function getSignalPerformance(signalId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(signalPerformance)
    .where(eq(signalPerformance.signalId, signalId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Create or update signal performance record
 */
export async function upsertSignalPerformance(
  signalId: number,
  performanceData: Omit<typeof signalPerformance.$inferInsert, "signalId">
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getSignalPerformance(signalId);

  if (existing) {
    return await db
      .update(signalPerformance)
      .set(performanceData)
      .where(eq(signalPerformance.signalId, signalId));
  } else {
    return await db.insert(signalPerformance).values({
      signalId,
      ...performanceData,
    });
  }
}

/**
 * Get KSE-100 index data
 */
export async function getLatestKseIndex() {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(kseIndex)
    .orderBy(desc(kseIndex.timestamp))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Record WhatsApp message log
 */
export async function createWhatsappLog(logData: typeof whatsappLogs.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(whatsappLogs).values(logData);
}

/**
 * Get performance metrics for a date range
 */
export async function getPerformanceMetrics(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(performanceMetrics)
    .where(and(gte(performanceMetrics.date, startDate), lte(performanceMetrics.date, endDate)))
    .orderBy(desc(performanceMetrics.date));
}

/**
 * Create or update daily performance metrics
 */
export async function upsertPerformanceMetrics(
  date: Date,
  metricsData: Omit<typeof performanceMetrics.$inferInsert, "date">
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db
    .select()
    .from(performanceMetrics)
    .where(eq(performanceMetrics.date, date))
    .limit(1);

  if (existing.length > 0) {
    return await db
      .update(performanceMetrics)
      .set(metricsData)
      .where(eq(performanceMetrics.date, date));
  } else {
    return await db.insert(performanceMetrics).values({
      date,
      ...metricsData,
    });
  }
}

/**
 * Get or create strategy
 */
export async function getStrategyById(strategyId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(strategies)
    .where(eq(strategies.id, strategyId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Create strategy
 */
export async function createStrategy(strategyData: typeof strategies.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(strategies).values(strategyData);
}

/**
 * Create strategy document
 */
export async function createStrategyDocument(
  docData: typeof strategyDocuments.$inferInsert
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(strategyDocuments).values(docData);
}

/**
 * Get strategy documents
 */
export async function getStrategyDocuments(strategyId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(strategyDocuments)
    .where(eq(strategyDocuments.strategyId, strategyId))
    .orderBy(desc(strategyDocuments.createdAt));
}

/**
 * Get all active subscribers for WhatsApp broadcast
 */
export async function getActiveSubscribers() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(users)
    .where(and(eq(users.isSubscribed, true), isNull(users.whatsappNumber) === false));
}

/**
 * Update user subscription and WhatsApp number
 */
export async function updateUserSubscription(
  userId: number,
  data: { whatsappNumber?: string; isSubscribed?: boolean; subscriptionTier?: any }
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(users)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(users.id, userId));
}

/**
 * Get all signals including closed ones for analytics
 */
export async function getAllSignals() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(signals)
    .orderBy(desc(signals.createdAt));
}
