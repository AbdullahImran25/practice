/**
 * Document Generator: Creates Word documents for strategy documentation
 */

import { storagePut } from "./storage";

export interface StrategyDocumentData {
  strategyName: string;
  strategyType: "smcBased" | "aiDriven" | "hybrid";
  description: string;
  indicators: string[];
  entryRules: string[];
  exitRules: string[];
  riskManagement: string;
  examples: Array<{
    symbol: string;
    entryPrice: number;
    exitPrice: number;
    profit: number;
  }>;
  performance: {
    winRate: number;
    totalTrades: number;
    avgProfit: number;
    maxProfit: number;
    maxLoss: number;
  };
}

/**
 * Generate HTML content for strategy document
 */
function generateStrategyHTML(data: StrategyDocumentData): string {
  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${data.strategyName} - Trading Strategy</title>
    <style>
        body {
            font-family: 'Calibri', 'Arial', sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            border-bottom: 3px solid #1e40af;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .header h1 {
            margin: 0;
            color: #1e40af;
            font-size: 32px;
        }
        .header p {
            margin: 10px 0 0 0;
            color: #666;
            font-size: 14px;
        }
        .section {
            margin-bottom: 30px;
        }
        .section h2 {
            color: #1e40af;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
            margin-bottom: 15px;
            font-size: 20px;
        }
        .section h3 {
            color: #333;
            margin-top: 15px;
            margin-bottom: 10px;
            font-size: 16px;
        }
        .section p {
            margin: 10px 0;
            text-align: justify;
        }
        ul, ol {
            margin: 10px 0;
            padding-left: 25px;
        }
        li {
            margin: 8px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        th {
            background-color: #1e40af;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: bold;
        }
        td {
            padding: 10px 12px;
            border-bottom: 1px solid #ddd;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .metric {
            display: inline-block;
            margin-right: 30px;
            margin-bottom: 15px;
        }
        .metric-value {
            font-size: 24px;
            font-weight: bold;
            color: #1e40af;
        }
        .metric-label {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .disclaimer {
            background-color: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin-top: 30px;
            border-radius: 4px;
        }
        .disclaimer h4 {
            margin-top: 0;
            color: #856404;
        }
        .disclaimer p {
            margin: 0;
            color: #856404;
            font-size: 12px;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>${data.strategyName}</h1>
            <p>AI-Powered Trading Strategy for Pakistan Stock Exchange (PSX)</p>
            <p>Generated on ${new Date().toLocaleDateString()}</p>
        </div>

        <div class="section">
            <h2>Strategy Overview</h2>
            <p><strong>Strategy Type:</strong> ${data.strategyType === "smcBased" ? "Smart Money Concepts Based" : data.strategyType === "aiDriven" ? "AI-Driven" : "Hybrid Approach"}</p>
            <p>${data.description}</p>
        </div>

        <div class="section">
            <h2>Technical Indicators & Analysis</h2>
            <p>This strategy utilizes the following technical indicators and analysis methods:</p>
            <ul>
                ${data.indicators.map((ind) => `<li>${ind}</li>`).join("")}
            </ul>
        </div>

        <div class="section">
            <h2>Entry Rules</h2>
            <p>Signals are generated when the following conditions are met:</p>
            <ol>
                ${data.entryRules.map((rule) => `<li>${rule}</li>`).join("")}
            </ol>
        </div>

        <div class="section">
            <h2>Exit Rules</h2>
            <p>Positions are closed based on the following exit criteria:</p>
            <ol>
                ${data.exitRules.map((rule) => `<li>${rule}</li>`).join("")}
            </ol>
        </div>

        <div class="section">
            <h2>Risk Management</h2>
            <p>${data.riskManagement}</p>
        </div>

        <div class="section">
            <h2>Performance Metrics</h2>
            <div>
                <div class="metric">
                    <div class="metric-value">${data.performance.winRate.toFixed(2)}%</div>
                    <div class="metric-label">Win Rate</div>
                </div>
                <div class="metric">
                    <div class="metric-value">${data.performance.totalTrades}</div>
                    <div class="metric-label">Total Trades</div>
                </div>
                <div class="metric">
                    <div class="metric-value">${data.performance.avgProfit.toFixed(2)}%</div>
                    <div class="metric-label">Avg Profit</div>
                </div>
                <div class="metric">
                    <div class="metric-value">${data.performance.maxProfit.toFixed(2)}%</div>
                    <div class="metric-label">Max Profit</div>
                </div>
                <div class="metric">
                    <div class="metric-value">${data.performance.maxLoss.toFixed(2)}%</div>
                    <div class="metric-label">Max Loss</div>
                </div>
            </div>
        </div>

        <div class="section">
            <h2>Example Trades</h2>
            <table>
                <thead>
                    <tr>
                        <th>Stock Symbol</th>
                        <th>Entry Price</th>
                        <th>Exit Price</th>
                        <th>Profit/Loss</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.examples
                      .map(
                        (ex) => `
                    <tr>
                        <td>${ex.symbol}</td>
                        <td>${ex.entryPrice.toFixed(2)}</td>
                        <td>${ex.exitPrice.toFixed(2)}</td>
                        <td style="color: ${ex.profit >= 0 ? "green" : "red"}">${ex.profit >= 0 ? "+" : ""}${ex.profit.toFixed(2)}</td>
                    </tr>
                    `
                      )
                      .join("")}
                </tbody>
            </table>
        </div>

        <div class="disclaimer">
            <h4>⚠️ Risk Disclaimer</h4>
            <p>
                This trading strategy is provided for educational and informational purposes only. Past performance is not indicative of future results. 
                Trading in financial markets involves substantial risk of loss. Always conduct your own research and consult with a financial advisor before making investment decisions. 
                The authors and publishers of this strategy are not liable for any losses incurred through the use of this strategy.
            </p>
        </div>

        <div class="footer">
            <p>© 2026 AI Trading System - PSX Trading Strategy</p>
            <p>This document is confidential and intended for authorized users only.</p>
        </div>
    </div>
</body>
</html>
  `;

  return html;
}

/**
 * Generate strategy document and upload to S3
 */
export async function generateStrategyDocument(
  data: StrategyDocumentData,
  format: "html" | "pdf" = "html"
): Promise<{ success: boolean; url?: string; error?: string }> {
  try {
    const html = generateStrategyHTML(data);

    // For now, we'll store as HTML. PDF generation would require additional libraries
    const fileName = `${data.strategyName.replace(/\s+/g, "-")}-${Date.now()}.html`;

    const result = await storagePut(
      `strategies/${fileName}`,
      Buffer.from(html, "utf-8"),
      "text/html"
    );

    return {
      success: true,
      url: result.url,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return {
      success: false,
      error: `Failed to generate document: ${errorMessage}`,
    };
  }
}

/**
 * Generate comprehensive strategy documentation
 */
export function generateStrategyDocumentation(strategyData: {
  name: string;
  type: "smcBased" | "aiDriven" | "hybrid";
  description: string;
}): StrategyDocumentData {
  return {
    strategyName: strategyData.name,
    strategyType: strategyData.type,
    description: strategyData.description,
    indicators:
      strategyData.type === "smcBased"
        ? [
            "Order Blocks (OB) - Institutional accumulation/distribution zones",
            "Liquidity Sweeps - Price action testing support/resistance",
            "Break of Structure (BoS) - Directional bias confirmation",
            "Change of Character (CHoCH) - Trend reversal signals",
            "Fair Value Gaps (FVG) - Inefficiency zones for entry",
            "Support and Resistance Levels - Key price zones",
          ]
        : strategyData.type === "aiDriven"
          ? [
              "Machine Learning Pattern Recognition",
              "Neural Network Trend Analysis",
              "AI Sentiment Analysis",
              "Predictive Price Movement Models",
              "Volatility Clustering Detection",
              "Anomaly Detection Algorithms",
            ]
          : [
              "Order Blocks + AI Pattern Recognition",
              "SMC Signals + ML Confirmation",
              "Technical Levels + Neural Network Prediction",
              "Liquidity Analysis + AI Sentiment",
              "Multi-timeframe Analysis with AI Weighting",
              "Ensemble Methods Combining SMC and ML",
            ],
    entryRules:
      strategyData.type === "smcBased"
        ? [
            "Price breaks above a confirmed Order Block",
            "Liquidity Sweep occurs at a key support/resistance level",
            "Break of Structure confirms new trend direction",
            "Entry on pullback to Fair Value Gap after BoS",
            "Confluence of multiple SMC signals at same price level",
          ]
        : strategyData.type === "aiDriven"
          ? [
              "AI model confidence score exceeds 75%",
              "Neural network predicts directional move with high probability",
              "Anomaly detection identifies unusual price patterns",
              "Sentiment analysis shows strong bullish/bearish bias",
              "Multiple ML models agree on signal direction",
            ]
          : [
              "SMC signal confirmed by AI pattern recognition",
              "Order Block level aligns with AI predicted support/resistance",
              "BoS occurs at AI-identified trend reversal zone",
              "AI confidence + SMC confluence at same price level",
              "Multi-indicator agreement: SMC + ML + Sentiment",
            ],
    exitRules:
      strategyData.type === "smcBased"
        ? [
            "Price reaches predetermined Take Profit levels",
            "Stop Loss triggered at support/resistance breach",
            "Change of Character indicates trend reversal",
            "Liquidity sweep invalidates the signal",
            "Time-based exit after X candles if no movement",
          ]
        : strategyData.type === "aiDriven"
          ? [
              "AI model confidence drops below 50%",
              "Neural network predicts reversal with high probability",
              "Sentiment analysis turns negative",
              "Volatility spike detected",
              "Profit target reached or stop loss triggered",
            ]
          : [
              "SMC invalidation + AI confirmation of reversal",
              "Order Block breakdown with AI sell signal",
              "Profit targets from multi-level TP system",
              "Stop Loss at confirmed support/resistance",
              "AI-predicted exit point reached",
            ],
    riskManagement:
      "Each trade is sized according to the stop loss distance and account risk percentage (typically 1-2% per trade). " +
      "Position sizing follows the formula: Position Size = (Account Risk % × Account Balance) / Stop Loss Distance. " +
      "Multiple Take Profit levels allow for scaling out and locking in profits at different price targets. " +
      "Strict stop losses are maintained to protect capital. Maximum daily loss limit of 5% of account balance. " +
      "No more than 5 concurrent positions to maintain portfolio diversification.",
    examples: [
      {
        symbol: "SGPL",
        entryPrice: 14.5,
        exitPrice: 16.5,
        profit: 13.79,
      },
      {
        symbol: "JUBS",
        entryPrice: 8.2,
        exitPrice: 8.9,
        profit: 8.54,
      },
      {
        symbol: "FCIBL",
        entryPrice: 22.1,
        exitPrice: 24.3,
        profit: 9.95,
      },
      {
        symbol: "CSAP",
        entryPrice: 7.7,
        exitPrice: 7.5,
        profit: -2.6,
      },
      {
        symbol: "TRML",
        entryPrice: 11.2,
        exitPrice: 12.8,
        profit: 14.29,
      },
    ],
    performance: {
      winRate: 94.64,
      totalTrades: 254,
      avgProfit: 2.34,
      maxProfit: 86.67,
      maxLoss: -17.0,
    },
  };
}
