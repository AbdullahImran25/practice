/**
 * WhatsApp Service: Integration with Twilio or Meta WhatsApp Business API
 * Sends automated trading signals to subscribers
 */

import { createWhatsappLog } from "./db";
import type { Signal } from "../drizzle/schema";

export interface WhatsappConfig {
  provider: "twilio" | "meta";
  accountSid?: string; // For Twilio
  authToken?: string; // For Twilio
  phoneNumber?: string; // For Twilio
  accessToken?: string; // For Meta
  businessAccountId?: string; // For Meta
  phoneNumberId?: string; // For Meta
}

/**
 * Format signal message for WhatsApp
 */
export function formatSignalMessage(signal: Signal, stockSymbol: string): string {
  const direction = signal.direction.toUpperCase();
  const type = signal.signalType.toUpperCase();
  const confidence = signal.confidence ? `${signal.confidence}%` : "N/A";

  let message = `🚀 *NEW TRADING SIGNAL*\n\n`;
  message += `📊 *Stock:* ${stockSymbol}\n`;
  message += `📈 *Type:* ${type}\n`;
  message += `🎯 *Direction:* ${direction}\n`;
  message += `💰 *Entry Price:* ${signal.entryPrice}\n`;

  if (signal.entryRange) {
    const range = signal.entryRange as { min: number; max: number };
    message += `📍 *Entry Range:* ${range.min} - ${range.max}\n`;
  }

  message += `🛑 *Stop Loss:* ${signal.stopLoss} (${signal.stopLossPercent}%)\n\n`;

  message += `🎁 *Take Profit Targets:*\n`;
  if (signal.takeProfits && Array.isArray(signal.takeProfits)) {
    const targets = signal.takeProfits as Array<{ level: number; price: number; percent: number }>;
    targets.forEach((tp, index) => {
      message += `  TP${tp.level}: ${tp.price} (+${tp.percent}%)\n`;
    });
  }

  message += `\n⚡ *Confidence:* ${confidence}\n`;
  message += `⏰ *Timeframe:* ${signal.timeframe}\n`;
  message += `📝 *Reason:* ${signal.reason || "AI-based analysis"}\n\n`;

  if (signal.aiAnalysis) {
    message += `🤖 *AI Analysis:*\n${signal.aiAnalysis}\n\n`;
  }

  message += `⚠️ *Risk Disclaimer:* Past performance is not indicative of future results. Always use proper risk management.`;

  return message;
}

/**
 * Send signal via WhatsApp using Twilio
 */
async function sendViaTwilio(
  config: WhatsappConfig,
  toPhoneNumber: string,
  message: string
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  if (!config.accountSid || !config.authToken || !config.phoneNumber) {
    return { success: false, error: "Twilio credentials not configured" };
  }

  try {
    // Twilio WhatsApp API endpoint
    const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${config.accountSid}/Messages.json`;

    const response = await fetch(twilioUrl, {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(`${config.accountSid}:${config.authToken}`).toString("base64")}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        From: `whatsapp:${config.phoneNumber}`,
        To: `whatsapp:${toPhoneNumber}`,
        Body: message,
      }).toString(),
    });

    if (!response.ok) {
      const error = await response.text();
      return { success: false, error: `Twilio error: ${error}` };
    }

    const data = (await response.json()) as { sid?: string };
    return { success: true, messageId: data.sid };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return { success: false, error: `Twilio send failed: ${errorMessage}` };
  }
}

/**
 * Send signal via WhatsApp using Meta Business API
 */
async function sendViaMeta(
  config: WhatsappConfig,
  toPhoneNumber: string,
  message: string
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  if (!config.accessToken || !config.phoneNumberId) {
    return { success: false, error: "Meta credentials not configured" };
  }

  try {
    // Meta WhatsApp Business API endpoint
    const metaUrl = `https://graph.instagram.com/v18.0/${config.phoneNumberId}/messages`;

    // Normalize phone number (remove + if present)
    const normalizedPhone = toPhoneNumber.replace(/\D/g, "");

    const response = await fetch(metaUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${config.accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: normalizedPhone,
        type: "text",
        text: {
          preview_url: true,
          body: message,
        },
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      return { success: false, error: `Meta error: ${error}` };
    }

    const data = (await response.json()) as { messages?: Array<{ id: string }> };
    const messageId = data.messages?.[0]?.id;
    return { success: true, messageId };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return { success: false, error: `Meta send failed: ${errorMessage}` };
  }
}

/**
 * Send trading signal via WhatsApp
 */
export async function sendSignalViaWhatsapp(
  config: WhatsappConfig,
  userId: number,
  signalId: number,
  toPhoneNumber: string,
  signal: Signal,
  stockSymbol: string
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    // Format the message
    const message = formatSignalMessage(signal, stockSymbol);

    // Send based on provider
    let result;
    if (config.provider === "twilio") {
      result = await sendViaTwilio(config, toPhoneNumber, message);
    } else if (config.provider === "meta") {
      result = await sendViaMeta(config, toPhoneNumber, message);
    } else {
      return { success: false, error: "Unknown WhatsApp provider" };
    }

    // Log the attempt
    await createWhatsappLog({
      userId,
      signalId,
      phoneNumber: toPhoneNumber,
      messageType: "signal",
      messageContent: message,
      status: result.success ? "sent" : "failed",
      externalId: result.messageId,
      errorMessage: result.error,
      sentAt: result.success ? new Date() : undefined,
    });

    return result;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";

    // Log the error
    await createWhatsappLog({
      userId,
      signalId,
      phoneNumber: toPhoneNumber,
      messageType: "signal",
      messageContent: "",
      status: "failed",
      errorMessage: errorMessage,
    });

    return { success: false, error: errorMessage };
  }
}

/**
 * Send alert message via WhatsApp
 */
export async function sendAlertViaWhatsapp(
  config: WhatsappConfig,
  userId: number,
  toPhoneNumber: string,
  alertTitle: string,
  alertMessage: string
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    const message = `🔔 *${alertTitle}*\n\n${alertMessage}\n\n⏰ ${new Date().toLocaleString()}`;

    // Send based on provider
    let result;
    if (config.provider === "twilio") {
      result = await sendViaTwilio(config, toPhoneNumber, message);
    } else if (config.provider === "meta") {
      result = await sendViaMeta(config, toPhoneNumber, message);
    } else {
      return { success: false, error: "Unknown WhatsApp provider" };
    }

    // Log the attempt
    await createWhatsappLog({
      userId,
      phoneNumber: toPhoneNumber,
      messageType: "alert",
      messageContent: message,
      status: result.success ? "sent" : "failed",
      externalId: result.messageId,
      errorMessage: result.error,
      sentAt: result.success ? new Date() : undefined,
    });

    return result;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";

    // Log the error
    await createWhatsappLog({
      userId,
      phoneNumber: toPhoneNumber,
      messageType: "alert",
      messageContent: "",
      status: "failed",
      errorMessage: errorMessage,
    });

    return { success: false, error: errorMessage };
  }
}

/**
 * Broadcast signal to all subscribers
 */
export async function broadcastSignalToSubscribers(
  config: WhatsappConfig,
  signal: Signal,
  stockSymbol: string,
  subscribers: Array<{ id: number; whatsappNumber: string }>
): Promise<{ successful: number; failed: number; errors: string[] }> {
  const results = {
    successful: 0,
    failed: 0,
    errors: [] as string[],
  };

  for (const subscriber of subscribers) {
    if (!subscriber.whatsappNumber) {
      results.failed++;
      results.errors.push(`Subscriber ${subscriber.id} has no WhatsApp number`);
      continue;
    }

    const result = await sendSignalViaWhatsapp(
      config,
      subscriber.id,
      signal.id,
      subscriber.whatsappNumber,
      signal,
      stockSymbol
    );

    if (result.success) {
      results.successful++;
    } else {
      results.failed++;
      results.errors.push(`Subscriber ${subscriber.id}: ${result.error}`);
    }

    // Rate limiting: wait 100ms between messages to avoid API throttling
    await new Promise((resolve) => setTimeout(resolve, 100));
  }

  return results;
}
