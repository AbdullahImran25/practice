# AI Trading System - Setup & Usage Guide

**Author:** Manus AI

## Introduction

This document provides a comprehensive guide for setting up and utilizing the AI-powered trading system designed for the Pakistan Stock Exchange (PSX). The system integrates advanced Smart Money Concepts (SMC) with artificial intelligence to generate real-time trading signals, aiming to enhance trading decisions through sophisticated analytical capabilities.

## 🚀 Quick Start

To initiate the system, follow these sequential steps:

1.  **Environment Configuration:** Begin by duplicating the `.env.example` file and renaming the copy to `.env`. Populate this new file with your specific database credentials and API keys. It is crucial to set the `OWNER_OPEN_ID` variable to your personal OpenID to establish administrative privileges within the system.

2.  **Dependency Installation:** Install all necessary project dependencies by executing the following command in your terminal:

    ```bash
    pnpm install
    ```

3.  **Database Migration:** Apply the required database schema migrations to your database. This step ensures that your database structure is compatible with the application's requirements. Execute the command:

    ```bash
    pnpm run db:push
    ```

4.  **Optional: Mock Data Seeding:** For testing purposes or to populate your dashboard with sample PSX stock data and technical indicators, you may run the mock data seeder. This step is optional and can be performed using the command:

    ```bash
    pnpm run db:seed
    ```

5.  **Application Launch:** Start the application in development mode by running:

    ```bash
    pnpm run dev
    ```

## 📱 WhatsApp Integration

The system offers seamless integration with WhatsApp for real-time signal notifications, supporting both Twilio and Meta (WhatsApp Business API) as providers. For ease of setup and testing, Twilio is generally recommended.

### Option 1: Twilio (Recommended for Ease of Use)

To configure WhatsApp notifications via Twilio, follow these steps:

1.  **Twilio Account Creation:** Register for a free account on the [Twilio platform][1].
2.  **Sandbox Access:** Navigate to the **Twilio Sandbox for WhatsApp** within your Twilio console.
3.  **Credential Retrieval:** Obtain your `Account SID`, `Auth Token`, and the designated sandbox phone number from the Twilio console.
4.  **Environment Variable Configuration:** Update your `.env` file with the retrieved Twilio credentials as follows:

    ```env
    WHATSAPP_PROVIDER=twilio
    TWILIO_ACCOUNT_SID=your_sid
    TWILIO_AUTH_TOKEN=your_token
    TWILIO_PHONE_NUMBER=+14155238886
    ```

5.  **Testing Notifications:** After configuring, log in to the application dashboard, proceed to your **Profile** settings, and enable notifications to send a test message.

### Option 2: Meta / WhatsApp Business API

For production environments or advanced use cases, the Meta WhatsApp Business API can be integrated:

1.  **Meta Developer Account:** Establish a developer account on [Meta for Developers][2].
2.  **WhatsApp Business App Setup:** Create a new WhatsApp Business App through the Meta developer portal.
3.  **Credential Retrieval:** Acquire your `Permanent Access Token` and `Phone Number ID` from your Meta Business App settings.
4.  **Environment Variable Configuration:** Configure your `.env` file with the Meta credentials:

    ```env
    WHATSAPP_PROVIDER=meta
    META_ACCESS_TOKEN=your_token
    META_PHONE_NUMBER_ID=your_phone_id
    ```

## 📈 Key Features Overview

### 1. AI-Powered Signal Generation

Signal generation is an administrative function, accessible via the **"Generate Signal"** button on the dashboard. The system autonomously analyzes market data, identifying Smart Money Concepts such as Order Blocks, Liquidity Sweeps, and Breaks of Structure. Each generated signal is accompanied by a detailed AI analysis, providing a clear rationale for the recommended trade.

### 2. Real-time WhatsApp Alerts

Upon generation, trading signals are automatically broadcast to all subscribed users via WhatsApp. These messages are meticulously formatted to include critical information such as Entry Price, Stop Loss, and multiple Take Profit targets, ensuring users receive actionable insights promptly.

### 3. Professional Dashboard

The interactive dashboard serves as the central hub for monitoring trading activities. It provides comprehensive analytics, including total signals generated, active trades, and overall win rate. Users can delve into the deep technical analysis and AI rationale for each active signal. Administrators possess the capability to close signals as targets are met or market conditions invalidate the initial setup.

### 4. Strategy Documentation

The system facilitates the generation of professional strategy reports. These documents, detailing various trading methodologies, can be viewed and exported from the dedicated **Strategies** section within the application.

## 🛠 Project Structure

The project is organized into several key directories, each serving a distinct purpose:

-   `/server`: Contains the backend tRPC routers, database query logic, and the core AI trading engine.
-   `/client`: Houses the React frontend, styled with Tailwind CSS and utilizing Shadcn UI components.
-   `/shared`: Stores shared types and constants, ensuring consistency between the frontend and backend.
-   `/drizzle`: Includes the database schema definitions and migration scripts.

## 🛡 Risk Disclaimer

It is imperative to understand that trading in financial markets inherently involves significant risk, including the potential loss of capital. While this system provides signals based on advanced AI analysis and technical patterns, it does not guarantee profits. Users are strongly advised to implement proper risk management strategies, including the use of stop losses, and to conduct their own due diligence before making any investment decisions.

## References

[1] [Twilio](https://www.twilio.com/)
[2] [Meta for Developers](https://developers.facebook.com/)
